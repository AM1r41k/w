﻿using FluentAPILesson.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace FluentAPILesson.Data
{
    public class DishesContext : DbContext
    {
        public DishesContext()
        {
            Database.Migrate();
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Dish> Dishes { get; set; }
        public DbSet<DishesProducts> DishesProducts { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=DESKTOP-H5GCVAL; Database=FluentAPILesson; Trusted_Connection=true;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().ToTable("products").Property(product => product.Id).HasColumnName("ID");
            modelBuilder.Entity<Product>().HasKey(product => product.Id);
            modelBuilder.Entity<Product>().Property(product => product.Name).HasColumnName("name").HasMaxLength(50).IsRequired();

            modelBuilder.Entity<Dish>().ToTable("dishes").Property(dish => dish.Id).HasColumnName("ID");
            modelBuilder.Entity<Dish>().HasKey(dish => dish.Id);
            modelBuilder.Entity<Dish>().Property(dish => dish.Name).HasColumnName("name").HasMaxLength(50).IsRequired();

            modelBuilder.Entity<DishesProducts>().ToTable("dishesProducts").Property(dp => dp.Id).HasColumnName("ID");
            modelBuilder.Entity<DishesProducts>().HasKey(DishesProducts => DishesProducts.Id);
            modelBuilder.Entity<DishesProducts>().HasOne(DishesProducts => DishesProducts.Dish).WithMany(dish => dish.DishesProducts);
            modelBuilder.Entity<DishesProducts>().HasOne(DishesProducts => DishesProducts.Product).WithMany(product => product.DishesProducts);

            base.OnModelCreating(modelBuilder);
        }
    }
}



