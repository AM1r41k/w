﻿using System;

namespace FluentAPILesson
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
