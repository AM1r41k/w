﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FluentAPILesson.Models
{
    public abstract class Entity
    {
     //   [Column("ID")]
     //   [Key] // Primary Key
        public Guid Id { get; set; } = Guid.NewGuid();
    }
}
