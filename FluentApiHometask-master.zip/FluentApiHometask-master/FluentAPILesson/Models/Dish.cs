﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FluentAPILesson.Models
{
    public class Dish : Entity
    {
        public string Name { get; set; }
        public ICollection<DishesProducts> DishesProducts { get; set; }
    }
}
