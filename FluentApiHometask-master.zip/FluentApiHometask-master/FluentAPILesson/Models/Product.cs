﻿using System;
using System.Collections.Generic;

namespace FluentAPILesson.Models
{
    public class Product :Entity
    {
        public string Name { get; set; }
        public ICollection<DishesProducts> DishesProducts { get; set; }
    }
}
